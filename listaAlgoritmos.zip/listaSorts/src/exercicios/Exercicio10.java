package exercicios;

import java.util.Random;

public class Exercicio10{

    public static void main(String[] args) {
        int[] tamanhos = {10000, 50000, 100000, 500000};

        for (int tamanho : tamanhos) {
            System.out.println("\nTamanho do vetor: " + tamanho);
            int[] ordenado = gerarOrdenado(tamanho);
            int[] invertido = gerarInvertido(tamanho);
            int[] aleatorio = gerarAleatorio(tamanho);

            System.out.println("\nVetor Ordenado:");
            testarTodos(ordenado);

            System.out.println("\nVetor Invertido:");
            testarTodos(invertido);

            System.out.println("\nVetor Aleatório:");
            testarTodos(aleatorio);
        }
    }

    public static void testarTodos(int[] vetorOriginal) {
        int[] bubble = vetorOriginal.clone();
        int[] selection = vetorOriginal.clone();
        int[] insertion = vetorOriginal.clone();

        long inicio, fim;

        inicio = System.nanoTime();
        int opBubble = bubbleSort(bubble);
        fim = System.nanoTime();
        System.out.println("Bubble Sort - Tempo: " + (fim - inicio) + " ns | Operações: " + opBubble);

        inicio = System.nanoTime();
        int opSelection = selectionSort(selection);
        fim = System.nanoTime();
        System.out.println("Selection Sort - Tempo: " + (fim - inicio) + " ns | Operações: " + opSelection);

        inicio = System.nanoTime();
        int opInsertion = insertionSort(insertion);
        fim = System.nanoTime();
        System.out.println("Insertion Sort - Tempo: " + (fim - inicio) + " ns | Operações: " + opInsertion);
    }

    public static int[] gerarOrdenado(int tamanho) {
        int[] vetor = new int[tamanho];
        for (int i = 0; i < tamanho; i++) {
            vetor[i] = i;
        }
        return vetor;
    }

    public static int[] gerarInvertido(int tamanho) {
        int[] vetor = new int[tamanho];
        for (int i = 0; i < tamanho; i++) {
            vetor[i] = tamanho - i;
        }
        return vetor;
    }

    public static int[] gerarAleatorio(int tamanho) {
        int[] vetor = new int[tamanho];
        Random r = new Random();
        for (int i = 0; i < tamanho; i++) {
            vetor[i] = r.nextInt(tamanho);
        }
        return vetor;
    }

    public static int bubbleSort(int[] vetor) {
        int op = 0;
        for (int i = 0; i < vetor.length - 1; i++) {
            for (int j = 0; j < vetor.length - i - 1; j++) {
                op++;
                if (vetor[j] > vetor[j + 1]) {
                    int temp = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = temp;
                }
            }
        }
        return op;
    }

    public static int selectionSort(int[] vetor) {
        int op = 0;
        for (int i = 0; i < vetor.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < vetor.length; j++) {
                op++;
                if (vetor[j] < vetor[min]) {
                    min = j;
                }
            }
            int temp = vetor[min];
            vetor[min] = vetor[i];
            vetor[i] = temp;
        }
        return op;
    }

    public static int insertionSort(int[] vetor) {
        int op = 0;
        for (int i = 1; i < vetor.length; i++) {
            int chave = vetor[i];
            int j = i - 1;
            while (j >= 0 && vetor[j] > chave) {
                vetor[j + 1] = vetor[j];
                j--;
                op++;
            }
            vetor[j + 1] = chave;
        }
        return op;
    }
}
