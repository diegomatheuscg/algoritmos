package exercicios;

import java.util.Scanner;
import java.util.Arrays;

public class Exercicio7 {

	public static void bubbleSortDecrescente(int[] vetor) {
		for (int i = 0; i < vetor.length - 1; i++) {
			for (int j = 0; j < vetor.length - 1 - i; j++) {
				if (vetor[j] < vetor[j + 1]) {
					int temp = vetor[j];
					vetor[j] = vetor[j + 1];
					vetor[j + 1] = temp;
				}
			}
		}
	}

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Quantas pontuações deseja inserir?");
		int tamanho = scanner.nextInt();

		int[] pontuacoes = new int[tamanho];

		for (int i = 0; i < tamanho; i++) {
			System.out.print("Digite a pontuação" + (i + 1) + ": ");
			pontuacoes[i] = scanner.nextInt();
		}

		bubbleSortDecrescente(pontuacoes);

		System.out.println("Pontuações Ordenadas: " + Arrays.toString(pontuacoes));
		System.out.println("Pontuação Mais Alta: " + pontuacoes[0]);

		scanner.close();
	}
}
