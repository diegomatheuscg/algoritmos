package exercicios;

public class Exercicio5 {

    public static void ordenarLinha(int[] linha) {
        int tamanho = linha.length;
        for (int i = 0; i < tamanho - 1; i++) {
            for (int j = 0; j < tamanho - 1 - i; j++) {
                if (linha[j] > linha[j + 1]) {
                    int temporario = linha[j];
                    linha[j] = linha[j + 1];
                    linha[j + 1] = temporario;
                }
            }
        }
    }

    public static void main(String[] args) {
        int[][] matriz = {
            {3, 2, 1},
            {6, 5, 4},
            {9, 8, 7}
        };

        for (int i = 0; i < matriz.length; i++) {
            ordenarLinha(matriz[i]);
        }

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + " ");
            }
            System.out.println();
        }
    }
}
