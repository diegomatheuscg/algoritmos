package exercicios;

public class Exercicio2 {

    public static void ordenarDecrescente(int[] vetor) {
        int tamanho = vetor.length;

        for (int i = 0; i < tamanho - 1; i++) {
            for (int j = 0; j < tamanho - i - 1; j++) {
                if (vetor[j] < vetor[j + 1]) {
                    int temporario = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = temporario;
                }
            }
        }
    }

    // Teste local
    public static void main(String[] args) {
        int[] vetor = {3, 0, -2, 5, 8};
        ordenarDecrescente(vetor);

        System.out.print("Vetor ordenado em ordem decrescente: ");
        for (int valor : vetor) {
            System.out.print(valor + " ");
        }
    }
}
