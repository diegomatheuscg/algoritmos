package exercicios;

import java.util.Arrays;

public class Exercicio6 {

    public static void bubbleSort(int[] vetor) {
        int n = vetor.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (vetor[j] > vetor[j + 1]) {
                    int aux = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = aux;
                }
            }
        }
    }

    public static double calcularMediana(int[] vetor) {
        int meio = vetor.length / 2;
        return (vetor[meio - 1] + vetor[meio]) / 2.0;
    }

    public static void main(String[] args) {
        int[] notas = {85, 70, 95, 60, 75, 80};

        bubbleSort(notas);

        System.out.println("Notas Ordenadas: " + Arrays.toString(notas));
        System.out.println("Mediana: " + calcularMediana(notas));
    }
}
