package exercicios;

public class Exercicio4 {

    public static void ordenarParcial(int[] vetor, int n) {
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - 1 - i; j++) {
                if (vetor[j] > vetor[j + 1]) {
                    int temporario = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = temporario;
                }
            }
        }
    }

    public static void main(String[] args) {
        int[] vetor = {8, 4, 3, 7, 6, 5, 2};
        int n = 4;

        ordenarParcial(vetor, n);

        for (int i = 0; i < vetor.length; i++) {
            System.out.print(vetor[i] + " ");
        }
    }
}
