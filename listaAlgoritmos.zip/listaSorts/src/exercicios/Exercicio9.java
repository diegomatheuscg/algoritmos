package exercicios;

import java.util.Random;

public class Exercicio9 {

	public static void main(String[] args) {
		int tamanho = 1000;

		int[] aleatorio = gerarAleatorio(tamanho);
		int[] ordenado = gerarOrdenado(tamanho);
		int[] invertido = gerarInvertido(tamanho);

		System.out.println("Aleatório:");
		testarTodos(aleatorio);

		System.out.println("\nOrdenado:");
		testarTodos(ordenado);

		System.out.println("\nInvertido:");
		testarTodos(invertido);
	}

	public static void testarTodos(int[] vetorOriginal) {
		int[] vetor1 = vetorOriginal.clone();
		int[] vetor2 = vetorOriginal.clone();
		int[] vetor3 = vetorOriginal.clone();

		long inicio, fim;

		inicio = System.nanoTime();
		bubbleSort(vetor1);
		fim = System.nanoTime();
		long tempoBubble = fim - inicio;

		inicio = System.nanoTime();
		selectionSort(vetor2);
		fim = System.nanoTime();
		long tempoSelection = fim - inicio;

		inicio = System.nanoTime();
		insertionSort(vetor3);
		fim = System.nanoTime();
		long tempoInsertion = fim - inicio;

		System.out.println("Bubble:    " + tempoBubble + " ns");
		System.out.println("Selection: " + tempoSelection + " ns");
		System.out.println("Insertion: " + tempoInsertion + " ns");

		if (tempoBubble < tempoSelection && tempoBubble < tempoInsertion) {
			System.out.println("Bubble Sort Venceu");
		} else if (tempoSelection < tempoBubble && tempoSelection < tempoInsertion) {
			System.out.println("Selection SortVenceu");
		} else {
			System.out.println("Insertion Sort Venceu");
		}
	}

	public static int[] gerarAleatorio(int tamanho) {
		int[] vetor = new int[tamanho];
		Random r = new Random();
		for (int i = 0; i < tamanho; i++) {
			vetor[i] = r.nextInt(1000);
		}
		return vetor;
	}

	public static int[] gerarOrdenado(int tamanho) {
		int[] vetor = new int[tamanho];
		for (int i = 0; i < tamanho; i++) {
			vetor[i] = i;
		}
		return vetor;
	}

	public static int[] gerarInvertido(int tamanho) {
		int[] vetor = new int[tamanho];
		for (int i = 0; i < tamanho; i++) {
			vetor[i] = tamanho - i;
		}
		return vetor;
	}

	public static void bubbleSort(int[] vetor) {
		for (int i = 0; i < vetor.length - 1; i++) {
			for (int j = 0; j < vetor.length - i - 1; j++) {
				if (vetor[j] > vetor[j + 1]) {
					int temp = vetor[j];
					vetor[j] = vetor[j + 1];
					vetor[j + 1] = temp;
				}
			}
		}
	}

	public static void selectionSort(int[] vetor) {
		for (int i = 0; i < vetor.length - 1; i++) {
			int min = i;
			for (int j = i + 1; j < vetor.length; j++) {
				if (vetor[j] < vetor[min]) {
					min = j;
				}
			}
			int temp = vetor[min];
			vetor[min] = vetor[i];
			vetor[i] = temp;
		}
	}

	public static void insertionSort(int[] vetor) {
		for (int i = 1; i < vetor.length; i++) {
			int chave = vetor[i];
			int j = i - 1;
			while (j >= 0 && vetor[j] > chave) {
				vetor[j + 1] = vetor[j];
				j--;
			}
			vetor[j + 1] = chave;
		}
	}
}
