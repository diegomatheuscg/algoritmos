package exercicios;

public class Exercicio1 {

    public static void bubbleSort(int[] vetorOriginal) {
        int[] vetor = vetorOriginal.clone();
        int tamanho = vetor.length;
        System.out.println("Bubble Sort:");
        for (int i = 0; i < tamanho - 1; i++) {
            for (int j = 0; j < tamanho - i - 1; j++) {
                if (vetor[j] > vetor[j + 1]) {
                    int temp = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = temp;
                }
            }
            imprimirPasso(vetor, i + 1);
        }
        System.out.println();
    }

    public static void selectionSort(int[] vetorOriginal) {
        int[] vetor = vetorOriginal.clone();
        int tamanho = vetor.length;
        System.out.println("Selection Sort:");
        for (int i = 0; i < tamanho - 1; i++) {
            int indiceMinimo = i;
            for (int j = i + 1; j < tamanho; j++) {
                if (vetor[j] < vetor[indiceMinimo]) {
                    indiceMinimo = j;
                }
            }
            int temp = vetor[indiceMinimo];
            vetor[indiceMinimo] = vetor[i];
            vetor[i] = temp;
            imprimirPasso(vetor, i + 1);
        }
        System.out.println();
    }

    public static void insertionSort(int[] vetorOriginal) {
        int[] vetor = vetorOriginal.clone();
        int tamanho = vetor.length;
        System.out.println("Insertion Sort:");
        for (int i = 1; i < tamanho; i++) {
            int chave = vetor[i];
            int j = i - 1;
            while (j >= 0 && vetor[j] > chave) {
                vetor[j + 1] = vetor[j];
                j--;
            }
            vetor[j + 1] = chave;
            imprimirPasso(vetor, i);
        }
        System.out.println();
    }

    public static void mergeSort(int[] vetorOriginal) {
        int[] vetor = vetorOriginal.clone();
        System.out.println("Merge Sort:");
        mergeSortRecursivo(vetor, 0, vetor.length - 1, 1);
        System.out.println();
    }

    private static void mergeSortRecursivo(int[] vetor, int inicio, int fim, int passo) {
        if (inicio < fim) {
            int meio = (inicio + fim) / 2;
            mergeSortRecursivo(vetor, inicio, meio, passo);
            mergeSortRecursivo(vetor, meio + 1, fim, passo);
            mesclar(vetor, inicio, meio, fim);
            imprimirPasso(vetor, passo);
        }
    }

    private static void mesclar(int[] vetor, int inicio, int meio, int fim) {
        int tamanho1 = meio - inicio + 1;
        int tamanho2 = fim - meio;

        int[] esquerda = new int[tamanho1];
        int[] direita = new int[tamanho2];

        for (int i = 0; i < tamanho1; ++i)
            esquerda[i] = vetor[inicio + i];
        for (int j = 0; j < tamanho2; ++j)
            direita[j] = vetor[meio + 1 + j];

        int i = 0, j = 0;
        int k = inicio;

        while (i < tamanho1 && j < tamanho2) {
            if (esquerda[i] <= direita[j]) {
                vetor[k] = esquerda[i];
                i++;
            } else {
                vetor[k] = direita[j];
                j++;
            }
            k++;
        }

        while (i < tamanho1) {
            vetor[k] = esquerda[i];
            i++;
            k++;
        }

        while (j < tamanho2) {
            vetor[k] = direita[j];
            j++;
            k++;
        }
    }

    private static void imprimirPasso(int[] vetor, int passo) {
        System.out.print("Passo " + passo + ": ");
        for (int valor : vetor) {
            System.out.print(valor + " ");
        }
        System.out.println();
    }

    // Teste local opcional:
    public static void main(String[] args) {
        int[] vetor = {3, 4, 9, 2, 5, 8, 2, 1, 7};
        bubbleSort(vetor);
        selectionSort(vetor);
        insertionSort(vetor);
        mergeSort(vetor);
    }
}
