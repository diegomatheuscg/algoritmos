package exercicios;

import java.util.Scanner;

public class Exercicio3 {

    public static void ordenarAlfabeticamente(String[] vetor) {
        int tamanho = vetor.length;

        for (int i = 0; i < tamanho - 1; i++) {
            for (int j = 0; j < tamanho - i - 1; j++) {
                if (vetor[j].compareTo(vetor[j + 1]) > 0) {
                    String temporario = vetor[j];
                    vetor[j] = vetor[j + 1];
                    vetor[j + 1] = temporario;
                }
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Quantas palavras você quer ordenar? ");
        int quantidade = scanner.nextInt();
        scanner.nextLine(); 

        String[] vetor = new String[quantidade];

        for (int i = 0; i < quantidade; i++) {
            System.out.print("Palavra " + (i + 1) + ": ");
            vetor[i] = scanner.nextLine();
        }

        ordenarAlfabeticamente(vetor);

        System.out.print("Palavras ordenadas: ");
        for (String palavra : vetor) {
            System.out.print(palavra + " ");
        }

        scanner.close();
    }
}
