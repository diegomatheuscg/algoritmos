package exercicios;

import java.util.ArrayList;
import java.util.List;

public class Exercicio8 {
	public static List<Paciente> gestaoHospitalar(List<Paciente> pacientes) {
		for (int i = 0; i < pacientes.size(); i++) {
			for (int j = 0; j < pacientes.size() - i - 1; j++) {
				Paciente atual = pacientes.get(j);
				Paciente proximo = pacientes.get(j + 1);
				if (proximo.getGravidade() > atual.getGravidade()
						|| (proximo.getGravidade() == atual.getGravidade() && proximo.getTempo() > atual.getTempo())) {
					pacientes.set(j, proximo);
					pacientes.set(j + 1, atual);
				}
			}
		}
		return pacientes;
	}

	public static void main(String[] args) {
		List<Paciente> pacientes = new ArrayList<>();
		pacientes.add(new Paciente("João", 3, 5));
		pacientes.add(new Paciente("Maria", 3, 10));
		pacientes.add(new Paciente("Lucas", 5, 2));

		List<Paciente> ordenados = gestaoHospitalar(pacientes);

		for (Paciente p : ordenados) {
			System.out.println(p.getNome());
		}
	}
}
